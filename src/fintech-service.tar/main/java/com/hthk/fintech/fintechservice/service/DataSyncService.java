package com.hthk.fintech.fintechservice.service;

/**
 * @Author: Rock CHEN
 * @Date: 2023/12/20 13:54
 */
public interface DataSyncService {



}
