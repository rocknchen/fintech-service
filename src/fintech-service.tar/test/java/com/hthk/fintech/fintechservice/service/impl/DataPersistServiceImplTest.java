package com.hthk.fintech.fintechservice.service.impl;

import org.junit.Before;

import static org.junit.Assert.*;

/**
 * @Author: Rock CHEN
 * @Date: 2024/1/5 16:13
 */
public class DataPersistServiceImplTest {

    @Before
    public void setUp() throws Exception {
    }
}